import Aos from 'aos';
import React, { useEffect } from 'react';
import './FunFlare.css';
import "aos/dist/aos.css";
import one from './boy.jpg';
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";



const FunFlare = () => {

      const responsive = {
        desktop: {
            breakpoint: { max: 3000, min: 1200 },
            items: 4,
            slidesToSlide: 1,
        },
        tablet: {
            breakpoint: { max: 1200, min: 768 },
            items: 2,
            slidesToSlide: 1,
        },
        mobile: {
            breakpoint: { max: 768, min: 0 },
            items: 1,
            slidesToSlide: 1,
      },
};
      
      useEffect(() => {
            Aos.init({
                  duration: 2000
            });
      }, []);

      return (
            <div id='photo-gallery'>
                  <h1 className='text_head'>Fun Flare 2022</h1>
                   <Carousel
                swipeable={true}
                draggable={true}
            //     showDots={true}
                responsive={responsive}
                ssr={true}
                autoPlay={true}
                infinite={true}
                autoPlaySpeed={1000}
                keyBoardControl={true}
                customTransition="all 1s"
                containerClass="carousel-container"
                removeArrowOnDeviceType={["tablet", "mobile"]}
                dotListClass="custom-dot-list-style"
                itemClass="carousel-item-padding-40-px"
                  >
                        <div>
                              <img src={one} alt=""/>
                        </div>
                         <div>
                              <img src={one} alt=""/>
                        </div>
                         <div>
                              <img src={one} alt=""/>
                        </div>
                         <div>
                              <img src={one} alt=""/>
                        </div>
                        </Carousel>
            </div>
      )
}

export default FunFlare